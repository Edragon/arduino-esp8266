var searchData=
[
  ['initspi_2530',['initSPI',['../espressif_2spi__board_8h.html#a4d0e7d467a943df2727239a46dd6fc7e',1,'initSPI(void):&#160;spi_board.h'],['../nrf52832_2spi__board_8h.html#a4d0e7d467a943df2727239a46dd6fc7e',1,'initSPI(void):&#160;spi_board.h']]]
];
