var searchData=
[
  ['pow2_4251',['POW2',['../utilities_8h.html#a4ccbcb603250aaa348c37eafb950cd48',1,'utilities.h']]]
];
