var searchData=
[
  ['utility_20functions_20and_20definitions_20_28platform_29_4357',['Utility Functions and Definitions (Platform)',['../group__app__util__platform.html',1,'']]]
];
