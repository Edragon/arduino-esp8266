# EPD_Libraries
A set of libraries for the ESP8266 and ESP32 (adapted from Waveshare)
